// LuaFunctions.cpp
#include <lua.hpp>
#include <cstdlib>
#include <ctime>

int randomName(lua_State* L) {
    static const char* names[] = {
        "Aragorn", "Boromir", "Celeborn", "Denethor", "Eowyn", "Faramir",
        "Galadriel", "Haldir", "Idril", "Jareth", "Kili", "Legolas",
        "Morgoth", "Nimloth", "Oropher", "Pippin", "Quickbeam", "Radagast",
        "Sauron", "Thranduil", "Ugluk", "Varda", "Wormtongue", "Xanathar",
        "Yavanna", "Zaragamba", "Anduril", "Bilbo", "Cirith", "Durin",
        "Eldarion", "Frodo", "Gimli", "Huan", "Isildur", "Jaromir",
        "Khazad", "Luthien", "Maedhros", "Nazgul", "Olwe", "Palantir",
        "Quendi", "Rivendell", "Shelob", "Tulkas", "Urukhai", "Valandil",
        "Witchking", "Xerxes", "Yazneg", "Zirakzigil", "Anarion", "Beorn",
        "Curunir", "Dori", "Elendil", "Feathered", "Goldberry", "Hurin",
        "Ilmare", "Joosten", "Khamul", "Lorien", "Mithrandir", "Noldor",
        "Oin", "Primula", "Q", "Ranger", "Shadowfax", "Turin",
        "Ungoliant", "Vanyar", "Westfold", "X-ray", "Yrch", "Zephyr",
        "Alatar", "Bombadil", "Cirdan", "Dwalin", "Eomer", "Feanor",
        "Glaurung", "Hobbiton", "Ingwe", "Jubayr", "Kili", "Lobelia",
        "Melkor", "Nienor", "Orome", "Peregrin", "Quickbeam", "Roac",
        "Smeagol", "Tauriel", "Uinen", "Voronwe", "Wargs", "Xanadu",
        "Yazan", "Zigil"
    };

    int index = rand() % 100;
    lua_pushstring(L, names[index]);

    return 1;  // return one value to Lua
}


int randomNumber(lua_State* L) {
    int min = (int)lua_tonumber(L, 1);
    int max = (int)lua_tonumber(L, 2);
    lua_pushnumber(L, min + rand() % (max - min + 1));
    return 1;  // return one value to Lua
}
