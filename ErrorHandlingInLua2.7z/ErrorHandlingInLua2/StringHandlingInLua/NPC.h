
// NPC.h
#pragma once
#include <iostream>
#include <string>

class NPC {
public:
    NPC(const std::string& name, int health, int attack, int defense, const std::string& role)
        : name(name), health(health), attack(attack), defense(defense), role(role) {}

    void display() const {
        std::cout << "Name: " << name << "\nRole: " << role << "\nHealth: " << health
            << "\nAttack: " << attack << "\nDefense: " << defense << std::endl;
    }

private:
    std::string name;
    int health;
    int attack;
    int defense;
    std::string role;
};
