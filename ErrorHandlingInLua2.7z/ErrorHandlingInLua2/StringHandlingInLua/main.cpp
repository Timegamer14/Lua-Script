// main.cpp
#include <iostream>
#include <string>
#include <lua.hpp>
#include "NPC.h"

extern int randomName(lua_State* L);
extern int randomNumber(lua_State* L);

int main() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    lua_State* L = luaL_newstate();
    luaL_openlibs(L);

    lua_register(L, "random_name", randomName);
    lua_register(L, "random_number", randomNumber);
    luaL_dofile(L, "NPC.lua");

    std::string choice;
    std::cout << "Choose NPC type (Heroic/Average): ";
    std::cin >> choice;

    if (choice == "Heroic") {
        lua_getglobal(L, "create_heroic_npc");
    }
    else {
        lua_getglobal(L, "create_average_npc");
    }

    lua_pcall(L, 0, 5, 0);

    // Extract NPC details
    std::string name = lua_tostring(L, -5);
    int health = (int)lua_tonumber(L, -4);
    int attack = (int)lua_tonumber(L, -3);
    int defense = (int)lua_tonumber(L, -2);
    std::string role = lua_tostring(L, -1);

    NPC npc(name, health, attack, defense, role);
    npc.display();

    lua_close(L);
    return 0;
}
