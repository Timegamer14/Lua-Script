-- test script to cause an error

function create_heroic_npc()
    local name = random_name()
    local role = "Hero"
    local health = random_number(100, 150)
    local attack = random_number(20, 30)
    local defense = random_number(15, 25)
    return name, health, attack, defense, role
end

function create_average_npc()
    local name = random_name()
    local role = "Average"
    local health = random_number(50, 100)
    local attack = random_number(10, 20)
    local defense = random_number(5, 15)
    return name, health, attack, defense, role
end
