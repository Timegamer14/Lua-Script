import random

NAMES = [
    "Aragorn", "Boromir", "Celeborn", "Denethor", "Eowyn",
    "Faramir", "Galadriel", "Haldir", "Idril", "Legolas",
    "Morgoth", "Nienor", "Oropher", "Palantir", "Quickbeam",
    "Radagast", "Sauron", "Thranduil", "Ugluk", "Varda",
    "Wormtongue", "Xanathar", "Yavanna", "Zaragamba", "Aragorn",
    "Balin", "Cirdan", "Durin", "Eldarion", "Frodo",
    "Gimli", "Huan", "Isildur", "Jubayr", "Kili",
    "Luthien", "Melkor", "Nimloth", "Orome", "Pippin",
    "Q", "Rohan", "Smeagol", "Turin", "Urukhai",
    "Valandil", "Witchking", "Xerxes", "Yazneg", "Zirakzigil",
    "Anduril", "Bilbo", "Cirith", "Dwalin", "Eomer",
    "Feanor", "Glaurung", "Hobbiton", "Ingwe", "Jaromir",
    "Khazad", "Lothlorien", "Maedhros", "Noldor", "Olwe",
    "Peregrin", "Quendi", "Rivendell", "Shelob", "Tulkas",
    "Ungoliant", "Vanyar", "Westfold", "X", "Yrch",
    "Zigil", "Anarion", "Beorn", "Curunir", "Dori",
    "Elendil", "Finrod", "Goldberry", "Hurin", "Ilmare",
    "Joosten", "Khamul", "Lorien", "Mithrandir", "Nazgul",
    "Oin", "Primula", "Quarrel", "Ranger", "Shadowfax",
    "Tauriel", "Uinen", "Valinor", "Wargs", "X-ray"
]



class NPC:
    def __init__(self, name, health, attack, defense, role):
        self.name = name
        self.health = health
        self.attack = attack
        self.defense = defense
        self.role = role

    def __str__(self):
        return f"Name: {self.name}\nRole: {self.role}\nHealth: {self.health}\nAttack: {self.attack}\nDefense: {self.defense}"


def random_name():
    return random.choice(NAMES)


def random_number(min_val, max_val):
    return random.randint(min_val, max_val)


def generate_npc(type):
    name = random_name()

    if type.lower() == "heroic":
        health = random_number(100, 150)
        attack = random_number(70, 100)
        defense = random_number(70, 100)
        role = "Hero"
    else:
        health = random_number(50, 100)
        attack = random_number(30, 70)
        defense = random_number(30, 70)
        role = "Commoner"

    return NPC(name, health, attack, defense, role)


if __name__ == "__main__":
    choice = input("Choose NPC type (Heroic/Average): ")
    npc = generate_npc(choice)
    print(npc)
